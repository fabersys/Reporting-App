//
//  ForgotPasswordViewController.swift
//  OoredoReports
//
//  Created by Kiranpal Reddy Gurijala on 7/12/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import UIKit
class ForgotPasswordViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var forgotUserIDField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder();
        return true
    }
    
    @IBAction func forgotPassword(_ sender: AnyObject) {
        ORCoreAPI.sharedAPI.forgotPassword(self.forgotUserIDField.text!, completion: { (json) ->Void in
            print("***Forgot Password ***",json)
            if(json != nil ){
                print("json", json)
            }
        })
        self.dismiss(animated: true, completion: nil)
    }
    
}
