//
//  ReportViewController.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 5/22/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import UIKit
import SwiftyJSON
import Charts
let newDate = Date()

extension Date {
    var month: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM"
        return dateFormatter.string(from: self)
    }
    var day: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd"
        return dateFormatter.string(from: self)
    }
    var year: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYY"
        return dateFormatter.string(from: self)
    }
    var monthDate: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "mm"
        return dateFormatter.string(from: self)
    }
}

let dateMonth  = newDate.month      // "Jun"
let dateDay   = newDate.day     // "07"
let dateYear = newDate.year   // "27"
let monthDate = newDate.monthDate
extension Float {
    var cleanValue: String {
        return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
}
class ReportViewController: UIViewController, LineChartDelegate {
    //var reportChart: UIView!
    var label = UILabel()
    var shouldMap = false;
    var username = "";
    var password = "";
    let fontSize1:CGFloat = 11.0
    let fonrSize2:CGFloat = 17.0
    let fontSiee3:CGFloat = UIDeviceOrientationIsLandscape(UIDevice.current.orientation) ? 15 : 20
    
    let BLUE = UIColor(red: (36.0/255.0), green: (97.0/255.0), blue: (144.0/255.0), alpha: 1.0)
    
    let PINK = UIColor(red: (147.0/255.0), green: (38.0/255.0), blue: (90.0/255.0), alpha: 1.0)
    
    let GREEN = UIColor(red: (32.0/255.0), green: (94.0/255.0), blue: (59.0/255.0), alpha: 1.0)
    
    let ORANGE = UIColor(red: (234.0/255.0), green: (104.0/255.0), blue: (25.0/255.0), alpha: 1.0)
    
    let DAYTAG = 1
    let TOTALVALTAG = 2
    let BLOCK1TAG = 3
    let BLOCK2TAG = 4
    let BLOCK3TAG = 5
    let PROJVALTAG = 6
    
    let CHEV1 = 31
    let VAL1 = 32
    let PERCENTVAL1 = 33
    let TYPE1 = 34
    
    let CHEV2 = 41
    let VAL2 = 42
    let PERCENTVAL2 = 43
    let TYPE2 = 44
    
    let CHEV3 = 51
    let VAL3 = 52
    let PERCENTVAL3 = 53
    let TYPE3 = 54
    
    let CHARTSPACE = 1000
    let CHARTCONTAINER = 100
    
    let CHART3 = 30
    let CHART2 = 20
    let CHART1 = 10
    
    
    var lineChart: LineChart!

    var selectedIndexPath:IndexPath!
    
    var deSelectedIndexPath: IndexPath!
    
    var reportExpandedTableCell: reportExpandedCell!
    
    //@IBOutlet weak var totalRevenue: UILabel!
    var myTimer:Timer?
    
    @IBOutlet weak var tableView: UITableView!
   
    override func viewWillAppear(_ animated: Bool) {
        self.view.isHidden = true
        self.navigationController?.isNavigationBarHidden = false
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        if( UserUtils.isInitialLogin() || self.shouldMap) {
//            let inputvc:InputViewController = self.storyboard?.instantiateViewControllerWithIdentifier("InputViewController") as! InputViewController
//            inputvc.username = self.username
//            inputvc.password = self.password
//            
//        }
        if(!UserUtils.isUserMapped() || !UserUtils.isUserLogged()){
            let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! LoginViewController
             DispatchQueue.main.async(execute: {
                self.present(loginVC, animated: true, completion: nil) })
        } else {
 
            self.view.isHidden = false
       }

        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.tintColor = UIColor.red
        
        let attributes = [
            NSForegroundColorAttributeName: UIColor.red,
            NSFontAttributeName: UIFont(name: "Exo-Bold", size: 25)!
        ]
        self.navigationController?.navigationBar.titleTextAttributes = attributes
        let btn = UIButton()
        btn.setImage(UIImage(named:"home_icon_logo.png"), for: UIControlState())
        btn.frame = CGRect(x: 0, y: 0, width: 130, height: 30)
        let leftbarbtn:UIBarButtonItem = UIBarButtonItem()
        leftbarbtn.customView = btn
        var btns = self.navigationItem.leftBarButtonItems
        btns?.append(leftbarbtn)
        self.navigationItem.leftBarButtonItems = btns
        
        
        let btn1 = UIButton()
        btn1.setTitle("powered by IMImobile", for: UIControlState())
        btn1.setTitleColor(UIColor.red, for: UIControlState())
//        btn1.backgroundColor = UIColor.grayColor()
        btn1.titleLabel?.textAlignment = NSTextAlignment.center
        btn1.titleLabel?.font = UIFont(name: "Exo-Light", size: 12)
        btn1.titleLabel?.numberOfLines = 2
        btn1.frame = CGRect(x: 0, y: 0, width: 80, height: 30)
        let rightbarbutn:UIBarButtonItem = UIBarButtonItem()
        rightbarbutn.customView = btn1
        self.navigationItem.rightBarButtonItems = [rightbarbutn]

//        btn.addTarget(self, action: #selector(ReportViewController.), forControlEvents: <#T##UIControlEvents#>)
        //self.reportChart=reportExpandedTableCell.inputView?.frame
        // Do any additional setup after loading the view.
        
        
        
//         let appDelegate:AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//         appDelegate.switchToDashboard()
        self.myTimer = Timer(timeInterval: 2.0, target: self, selector: #selector(ReportViewController.refresh), userInfo: nil, repeats: false)
        RunLoop.main.add(self.myTimer!, forMode: RunLoopMode.defaultRunLoopMode)

    }
    func refresh() {
        // a refresh of the table
        self.tableView.reloadData()
    }
    func setDaySummaryChart(_ dataPoints: [String], values: [Double]) {
        var dataEntries: [ChartDataEntry] = []
        
        for i in 0..<dataPoints.count {
            let dataEntry = ChartDataEntry(value: values[i], xIndex: i)
            dataEntries.append(dataEntry)
        }
        let pieChartDataSet = PieChartDataSet(yVals: dataEntries, label: "")
        let pieChartData = PieChartData(xVals: dataPoints, dataSet: pieChartDataSet)
        pieChartDataSet.valueLinePart1OffsetPercentage = 0.8
        pieChartDataSet.valueLinePart1Length = 0.3
        pieChartDataSet.valueLinePart2Length = 0.1
        pieChartDataSet.xValuePosition = .OutsideSlice
        pieChartDataSet.yValuePosition = .OutsideSlice
         self.reportExpandedTableCell.reportView.drawSliceTextEnabled = false
        self.reportExpandedTableCell.reportView.usePercentValuesEnabled = true
        self.reportExpandedTableCell.reportView.descriptionText=""
        self.reportExpandedTableCell.reportView.holeColor = UIColor(red: 0.149, green: 0.149, blue: 0.149, alpha: 1)
        
        self.reportExpandedTableCell.reportView.legend.position = ChartLegend.Position.BelowChartCenter
        self.reportExpandedTableCell.reportView.legend.textColor = UIColor.lightGrayColor()
        
        
        pieChartDataSet.colors = [BLUE,ORANGE,GREEN,PINK]
        self.reportExpandedTableCell.reportView.data = pieChartData
    }

    
    func setLineChart(_ xLabels: [String], data: [Double:Double]){
        print(xLabels.count, data.count)
        print("Hello", data)
        print(xLabels)
        
        let historicalUsageTimes = [Double](data.keys)
        let historicalUsageValues = [Double](data.values)
        
        var views: [String: AnyObject] = [:]
        
        label.text = "..."
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = NSTextAlignment.center
        views["label"] = label
        
        self.reportExpandedTableCell.LMVsCMTDReportsChart.animate(xAxisDuration: 2.0, yAxisDuration: 3.0, easingOption:  .EaseInOutCubic)
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        if xLabels.count > 1 {
            for i in 1..<xLabels.count {
                let dataEntry1 = ChartDataEntry(value: historicalUsageTimes[i]/1000, xIndex: i)
                dataEntries1.append(dataEntry1)
                let dataEntry2 = ChartDataEntry(value: historicalUsageValues[i]/1000, xIndex: i)
                dataEntries2.append(dataEntry2)
            }
        }
        var colors: [UIColor] = []
        for _ in 0..<historicalUsageTimes.count {
            let red = Double(arc4random_uniform(256))
            let green = Double(arc4random_uniform(256))
            let blue = Double(arc4random_uniform(256))
            
            let color = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
            colors.append(color)
        }
        
        let lineChartDataSet1 = LineChartDataSet(yVals: dataEntries1, label: "LMTD")
        let lineChartDataSet2 = LineChartDataSet(yVals: dataEntries2, label: "CMTD")
        lineChartDataSet1.circleRadius=3.0
        lineChartDataSet1.circleHoleColor = UIColor(red: 0.192, green: 0.463, blue: 0.627, alpha: 1)
        lineChartDataSet1.circleColors = [UIColor(red: 0.192, green: 0.463, blue: 0.627, alpha: 1)]
        lineChartDataSet1.setColor(UIColor(red: 0.192, green: 0.463, blue: 0.627, alpha: 1))
        lineChartDataSet1.drawValuesEnabled = false
        lineChartDataSet1.valueColors = [UIColor.clearColor()]
        lineChartDataSet1.valueTextColor = UIColor.clearColor()
        lineChartDataSet1.drawFilledEnabled = false
        lineChartDataSet1.drawCubicEnabled = true;
        lineChartDataSet1.cubicIntensity = 0.3;
        lineChartDataSet1.highlightEnabled = false
        
        lineChartDataSet2.circleRadius=3.0
        lineChartDataSet2.circleHoleColor = UIColor(red: 0.639, green: 0.239, blue: 0.427, alpha: 1)
        lineChartDataSet2.circleColors = [UIColor(red: 0.639, green: 0.239, blue: 0.427, alpha: 1)]
        lineChartDataSet2.setColor(UIColor(red: 0.639, green: 0.239, blue: 0.427, alpha: 1))
        lineChartDataSet2.drawValuesEnabled = false
        lineChartDataSet2.valueColors = [UIColor.clearColor()]
        lineChartDataSet2.valueTextColor = UIColor.clearColor()
        lineChartDataSet2.drawFilledEnabled = false
        lineChartDataSet2.drawCubicEnabled = true;
        lineChartDataSet2.cubicIntensity = 0.3;
        lineChartDataSet2.highlightEnabled = false
        
        var dataSets:[LineChartDataSet]=[]
        dataSets.append(lineChartDataSet2)
        dataSets.append(lineChartDataSet1)
        let lineChartData = LineChartData(xVals: xLabels, dataSets: dataSets)
        self.reportExpandedTableCell.LMVsCMTDReportsChart.leftAxis.labelTextColor = UIColor(red:0.510, green:0.514, blue:0.533, alpha:1.00)
        self.reportExpandedTableCell.LMVsCMTDReportsChart.leftAxis.labelCount = 10
        self.reportExpandedTableCell.LMVsCMTDReportsChart.data = lineChartData
        self.reportExpandedTableCell.LMVsCMTDReportsChart.rightAxis.labelTextColor = UIColor(red:0.510, green:0.514, blue:0.533, alpha:1.00)
        
        let yaxis = self.reportExpandedTableCell.LMVsCMTDReportsChart.getAxis(ChartYAxis.AxisDependency.Right)
        yaxis.drawLabelsEnabled = false
        self.reportExpandedTableCell.LMVsCMTDReportsChart.xAxis.labelPosition = .Bottom
        self.reportExpandedTableCell.LMVsCMTDReportsChart.xAxis.labelTextColor = UIColor(red:0.510, green:0.514, blue:0.533, alpha:1.00)
        self.reportExpandedTableCell.LMVsCMTDReportsChart.rightAxis.drawLabelsEnabled=false
        self.reportExpandedTableCell.LMVsCMTDReportsChart.rightAxis.drawAxisLineEnabled = false;
        self.reportExpandedTableCell.LMVsCMTDReportsChart.leftAxis.startAtZeroEnabled = false
        self.reportExpandedTableCell.LMVsCMTDReportsChart.leftAxis.drawGridLinesEnabled = false
        self.reportExpandedTableCell.LMVsCMTDReportsChart.xAxis.drawGridLinesEnabled = false
        self.reportExpandedTableCell.LMVsCMTDReportsChart.rightAxis.drawGridLinesEnabled = false;
        self.reportExpandedTableCell.LMVsCMTDReportsChart.legend.position = ChartLegend.Position.BelowChartCenter
        self.reportExpandedTableCell.LMVsCMTDReportsChart.legend.textColor = UIColor.whiteColor()
        self.reportExpandedTableCell.LMVsCMTDReportsChart.descriptionText = ""
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func formatNumber(_ num: Int64) -> String {
        var stringNumber: String
        if num < 1000 {
            stringNumber = "\(num)"
        }
        else if num < 1000000 {
            let newNumber: Float = floor(Float(num / 100)) / 10.0
            stringNumber = String(format: "%.1fk", newNumber)
        }
        else {
            let newNumber: Float = floor(Float(num / 100000)) / 10.0
            stringNumber = String(format: "%.1fm", newNumber)
        }
        
        return stringNumber
    }
    
    func numberOfSectionsInTableView(_ tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 3
    }
    
    func tableView(_ tableView: UITableView!, heightForRowAtIndexPath indexPath: IndexPath!) -> CGFloat {
        
        if(selectedIndexPath != nil && selectedIndexPath == indexPath){
            return UIDevice.current.userInterfaceIdiom == .phone ? 420.0 : 450.0
        }
        return UIDevice.current.userInterfaceIdiom == .phone ? 190.0 : 210.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAtIndexPath indexPath: IndexPath) {
        
        selectedIndexPath = indexPath;
        let cell = tableView.cellForRow(at: indexPath)
        let v = cell?.viewWithTag(1000)
        if ((v?.isHidden) != true) {
            selectedIndexPath = nil
          tableView.deselectRow(at: indexPath, animated: true)
            tableView.delegate?.tableView!(tableView, didDeselectRowAt: indexPath)
        }
        else{
            v?.isHidden = false;
            tableView.beginUpdates()
            tableView.endUpdates()
            
        }
        
    }
    func tableView(_ tableView: UITableView, didDeselectRowAtIndexPath indexPath: IndexPath) {
         deSelectedIndexPath = indexPath
        
        let cell = tableView.cellForRow(at: indexPath)
        
        let v = cell?.viewWithTag(1000)
        
        v?.isHidden = true;
        
        self.tableView.beginUpdates()
        
        self.tableView.endUpdates()
     }
    
    func tableView(_ tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell {
        
      self.reportExpandedTableCell = tableView.dequeueReusableCell(withIdentifier: reportExpandedCell.tableCellId(), for: indexPath) as! reportExpandedCell
        let view = self.reportExpandedTableCell.viewWithTag(10)
        view?.layer.cornerRadius = 10.0
        
        let day:UILabel = self.reportExpandedTableCell.viewWithTag(self.DAYTAG) as! UILabel
        let projectedRevenue:UILabel = self.reportExpandedTableCell.viewWithTag(self.PROJVALTAG) as! UILabel
        let changeValuePercentile:UILabel = self.reportExpandedTableCell.viewWithTag(self.PERCENTVAL1) as! UILabel
        let dodMoMYoY:UILabel = self.reportExpandedTableCell.viewWithTag(self.TYPE1) as! UILabel
        
        let dmyRevenue:UILabel = self.reportExpandedTableCell.viewWithTag(self.VAL1) as! UILabel
        let totalRevenue:UILabel = self.reportExpandedTableCell.viewWithTag(self.TOTALVALTAG) as! UILabel
        
        let revenueLabel:UIView = self.reportExpandedTableCell.viewWithTag(self.CHART3)! as UIView
        
        let f = UIFont(name: "Exo-Regular",size: 12.0)
        day.font = f

        let chartspace = self.reportExpandedTableCell.viewWithTag(CHARTSPACE)
        chartspace?.layer.cornerRadius = 5.0
        chartspace?.layer.borderColor = UIColor.lightGray.cgColor
        chartspace?.layer.borderWidth = 1.0
        
        self.reportExpandedTableCell.leftButton.addTarget(self, action: #selector(ReportViewController.leftTapped(_:)), for: .touchUpInside)
        
        self.reportExpandedTableCell.rightButton.addTarget(self, action: #selector(ReportViewController.rightTapped(_:)), for: .touchUpInside)
        
        /****/
        
        let containerView = self.reportExpandedTableCell.viewWithTag(100)
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(ReportViewController.handleSwipes(_:)))
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(ReportViewController.handleSwipes(_:)))
        leftSwipe.direction = .left
        rightSwipe.direction = .right
        containerView!.addGestureRecognizer(leftSwipe)
        containerView!.addGestureRecognizer(rightSwipe)
        
        /******/
        
//        self.reportExpandedTableCell.reportView.tap
         var dataSetLabels:[Double:Double]=[:]
        var dataSetLabelsDouble:[Double:Double]=[:]
        var xAxisLabels:[String]=[]
        
        var cdVsldReportOrganized:[[Int:[Double:Double]]] = [[Int:[Double:Double]]]()
        var cmVslmReportOrganized:[[Int:[Double:Double]]] = [[Int:[Double:Double]]]()
        var cyVslyReportOrganized:[[Int:[Double:Double]]] = [[Int:[Double:Double]]]()
        if(indexPath.row==0){
            day.text = String(dateDay)+"-"+String(dateMonth)+"-"+String(dateYear)
            totalRevenue.text = "$"+formatNumber(Int64(ORPollingService.sharedService.CDTotal))
            projectedRevenue.text = "$"+formatNumber(Int64(ORPollingService.sharedService.CDProjectedRevenue))
            dmyRevenue.text = formatNumber(Int64(ORPollingService.sharedService.DoDRevenue))
            changeValuePercentile.text = "("+String(format:"%.1f",ORPollingService.sharedService.DoDPercentage)+"%"+")"
            dodMoMYoY.text = "DoD"
            if(ORPollingService.sharedService.DoDRevenue<0.0){
                print("red")
                revenueLabel.backgroundColor = hexStringToUIColor("#c80918")
            }
            else{
                print("green")
                revenueLabel.backgroundColor = hexStringToUIColor("#64bf62")
            }
            setDaySummaryChart([String](ORPollingService.sharedService.CDServiceWiseSummary.keys), values: [Double](ORPollingService.sharedService.CDServiceWiseSummary.values))
            var unSortedCodeKeys = Array(ORPollingService.sharedService.cdVsldReport)
            let sortedCodeKeys:[String] = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"]
            for  _ in 0..<24 {
                cdVsldReportOrganized.append([0:[0.0:0.0]]);
            }
            
            if(unSortedCodeKeys.count>0){
                for i in 0 ..< unSortedCodeKeys.count {
                    let d = unSortedCodeKeys[i]
                    let idx = d.0
                    let val = [d.0 : d.1];
                        cdVsldReportOrganized[idx] =  val ;
                        print(ORPollingService.sharedService.cdVsldReport[i])
                        print(unSortedCodeKeys[i]);
                }
            }
            print("cdVsldReportOrganized", cdVsldReportOrganized)
            xAxisLabels = [String](sortedCodeKeys)
            let x:[[Double:Double]] = Array(ORPollingService.sharedService.cdVsldReport.values)
            var y:[[Double:Double]]=[]
            if(x.count>0){
            for i in 0..<cdVsldReportOrganized.count{
                y.append((cdVsldReportOrganized[i])[i]!)
            }
            print("y", y)
            for i in 0..<y.count{
                dataSetLabels[Double(Array(x[i].keys)[0])] = Double(Array(x[i].values)[0])
            }
            setLineChart(xAxisLabels, data: dataSetLabels)
            }
        }
        else if(indexPath.row==1){

            day.text = String(dateMonth)+"-"+String(dateYear)
            totalRevenue.text = "$"+formatNumber(Int64(ORPollingService.sharedService.CMTotal))
            projectedRevenue.text = "$"+formatNumber(Int64(ORPollingService.sharedService.CMProjectedRevenue))
            setDaySummaryChart([String](ORPollingService.sharedService.CMServiceWiseSummary.keys), values: [Double](ORPollingService.sharedService.CMServiceWiseSummary.values))
            dodMoMYoY.text = "MoM"
            dmyRevenue.text = formatNumber(Int64(ORPollingService.sharedService.MoMRevenue))
            changeValuePercentile.text = "("+String(format:"%.1f",ORPollingService.sharedService.MoMPercentage)+"%"+")"
            
            if(ORPollingService.sharedService.MoMRevenue<0.0){
                revenueLabel.backgroundColor = hexStringToUIColor("#c80918")
            }
            else{
                revenueLabel.backgroundColor = hexStringToUIColor("#64bf62")
            }
            
            var unSortedCodeKeys = Array(ORPollingService.sharedService.cmVslmReportDouble)
            let sortedCodeKeys:[String] = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29","30"]
            for  i in 0..<31 {
                cmVslmReportOrganized.append([0:[0.0:0.0]]);
            }
            print("unSortedCodeKeys", unSortedCodeKeys.count, unSortedCodeKeys, cmVslmReportOrganized.count)
            if(unSortedCodeKeys.count>0){
                for i in 0 ..< unSortedCodeKeys.count {
                    let d = unSortedCodeKeys[i]
                     print(d.0, d.1)
                    let idx = d.0
                    let val = [d.0 : d.1];
                    cmVslmReportOrganized[idx] =  val ;
                }
            }
//            cmVslmReportOrganized.removeAtIndex(0)
            print("cmVslmReportOrganized", cmVslmReportOrganized)
            xAxisLabels = [String](sortedCodeKeys)
            let x:[[Double:Double]] = Array(ORPollingService.sharedService.cmVslmReportDouble.values)
            var y:[[Double:Double]]=[]
            if(x.count>0){
                for i in 1..<cmVslmReportOrganized.count{
                    y.append((cmVslmReportOrganized[i])[i]!)
                }
                print("y", y)
                for i in 0..<y.count{
                    dataSetLabels[Double(Array(x[i].keys)[0])] = Double(Array(x[i].values)[0])
                }
                setLineChart(xAxisLabels, data: dataSetLabels)
            }

        }
        else{
            day.text = String(dateYear)
            dodMoMYoY.text = "YoY"
            totalRevenue.text = "$"+formatNumber(Int64(ORPollingService.sharedService.CYTotal))
            projectedRevenue.text = "$"+formatNumber(Int64(ORPollingService.sharedService.CYProjectedRevenue))
            
                dmyRevenue.text = formatNumber(Int64(ORPollingService.sharedService.MoMRevenue))

            setDaySummaryChart([String](ORPollingService.sharedService.CMServiceWiseSummary.keys), values: [Double](ORPollingService.sharedService.CMServiceWiseSummary.values))
            dmyRevenue.text = formatNumber(Int64(ORPollingService.sharedService.YoYRevenue))
            changeValuePercentile.text = "("+String(format:"%.1f",ORPollingService.sharedService.YoYPercentage)+"%"+")"
            
            if(ORPollingService.sharedService.YoYRevenue<0.0){
                revenueLabel.backgroundColor = hexStringToUIColor("#c80918")
            }
            else{
                revenueLabel.backgroundColor = hexStringToUIColor("#64bf62")
            }
            
            var unSortedCodeKeys = Array(ORPollingService.sharedService.cyVslyReport)
            let sortedCodeKeys:[String] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            for  _ in 0..<12 {
                cyVslyReportOrganized.append([0:[0.0:0.0]]);
            }
            
            if(unSortedCodeKeys.count>0){
                for i in 0 ..< unSortedCodeKeys.count {
                    let d = unSortedCodeKeys[i]
                    let idx = d.0
                    let val = [d.0 : d.1];
                    cyVslyReportOrganized[idx] =  val ;
                    print(ORPollingService.sharedService.cyVslyReport[i])
                    print(unSortedCodeKeys[i]);
                }
            }
            print("cdVsldReportOrganized", cdVsldReportOrganized)
            xAxisLabels = [String](sortedCodeKeys)
            let x:[[Double:Double]] = Array(ORPollingService.sharedService.cyVslyReport.values)
            var y:[[Double:Double]]=[]
            if(x.count>0){
                for i in 0..<cyVslyReportOrganized.count{
                    y.append((cyVslyReportOrganized[i])[i]!)
                }
                print("y", y)
                for i in 0..<y.count{
                    dataSetLabels[Double(Array(x[i].keys)[0])] = Double(Array(x[i].values)[0])
                }
                setLineChart(xAxisLabels, data: dataSetLabels)
            }
        }
        self.reportExpandedTableCell.selectionStyle = UITableViewCellSelectionStyle.none
        return self.reportExpandedTableCell
    }

    func ascendingTest(_ value1: Int, value2: Int) -> Bool {
        return value1 < value2;
    }
    
    func leftTapped(_ sender:UIButton){
        print("left tapped")
        let cell:reportExpandedCell = sender.superview?.superview?.superview?.superview as! reportExpandedCell
        self.reportExpandedTableCell = cell
        if(self.reportExpandedTableCell.LMVsCMTDReportsChart.hidden){
            UIView.animate(withDuration: 5.0, animations: {
                self.reportExpandedTableCell.LMVsCMTDReportsChart.hidden = false
                self.reportExpandedTableCell.reportView.hidden = true
            })
        }
   
    }
    
    func rightTapped(_ sender:UIButton){
        print("right tapped")
        let cell:reportExpandedCell = sender.superview?.superview?.superview?.superview as! reportExpandedCell
        self.reportExpandedTableCell = cell
        print(cell)
        if(self.reportExpandedTableCell.reportView.hidden){
            UIView.animate(withDuration: 5.0, animations: {
                self.reportExpandedTableCell.LMVsCMTDReportsChart.hidden = true
                self.reportExpandedTableCell.reportView.hidden = false
            })
        }
        
        
    }
    func handleSwipes(_ sender:UISwipeGestureRecognizer) {
        let view = sender.view
        let point = sender.location(in: view)
        
        let transition:CATransition = CATransition()
        transition.duration = 5.0
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromLeft
        transition.timingFunction = CAMediaTimingFunction(name:kCAMediaTimingFunctionEaseInEaseOut)
        
        let subview = view?.hitTest(point, with: nil)
        
        
        self.reportExpandedTableCell.reportView = view?.viewWithTag(10) as! PieChartView
        self.reportExpandedTableCell.LMVsCMTDReportsChart = view?.viewWithTag(20) as! LineChartView
         let v3 = view?.viewWithTag(30)
        
        if (sender.direction == .left) {
        
            if(subview == v3){
                
                
                
            } else if(subview == self.reportExpandedTableCell.LMVsCMTDReportsChart){
                UIView.animate(withDuration: 5.0, animations: {
                    self.reportExpandedTableCell.LMVsCMTDReportsChart?.hidden = true
                    self.reportExpandedTableCell.reportView?.hidden = false
                    v3?.isHidden = true
                    

                })
                
                
            }else if(subview == self.reportExpandedTableCell.reportView){
                UIView.animate(withDuration: 5.0, animations: {
                    self.reportExpandedTableCell.LMVsCMTDReportsChart?.hidden = true
                    self.reportExpandedTableCell.reportView?.hidden = true
                    v3?.isHidden = false
                })
            }
            
        }
        if (sender.direction == .right) {
            
            if(subview == v3){
                UIView.animate(withDuration: 5.0, animations: {
                    self.reportExpandedTableCell.LMVsCMTDReportsChart?.hidden = true
                    self.reportExpandedTableCell.reportView?.hidden = false
                    v3?.isHidden = true
                })
                
            } else if(subview == self.reportExpandedTableCell.LMVsCMTDReportsChart){
                
//                UIView.animateWithDuration(5.0, animations: {
//                    self.reportExpandedTableCell.LMVsCMTDReportsChart?.hidden = true
//                    self.reportExpandedTableCell.reportView?.hidden = false
//                    v3?.hidden = true
//                })
//                
            }else if(subview == self.reportExpandedTableCell.reportView){
                UIView.animate(withDuration: 5.0, animations: {
                    self.reportExpandedTableCell.LMVsCMTDReportsChart?.hidden = false
                    self.reportExpandedTableCell.reportView?.hidden = true
                    v3?.isHidden = true
                })
                
            }
        }
        
    }
    /**
     * Line chart delegate method.
     */
    func didSelectDataPoint(_ x: CGFloat, yValues: Array<CGFloat>) {
        //label.text = "x: \(x)     y: \(yValues)"
    }
    func hexStringToUIColor (_ hex:String) -> UIColor {
        var cString:String = hex.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet() as NSCharacterSet).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString = cString.substring(from: cString.characters.index(cString.startIndex, offsetBy: 1))
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    

}
class reportExpandedCell: UITableViewCell {
    // MARK: - Class Properties
    @IBOutlet weak var reportView: PieChartView!
    @IBOutlet weak var LMVsCMTDReportsChart: LineChartView!
    
    @IBOutlet weak var leftButton: UIButton!
    @IBOutlet weak var rightButton: UIButton!
    
    class func tableCellId() -> String {
        return UIDevice.current.userInterfaceIdiom == .phone ?  "reportExpandedCell" : "reportExpandedCell_iPad"
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        LMVsCMTDReportsChart.gestureRecognizers = nil
    }
    
}
