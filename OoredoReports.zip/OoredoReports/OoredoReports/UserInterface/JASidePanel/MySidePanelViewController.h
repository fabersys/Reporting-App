//
//  MySidePanelViewController.h
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/2/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JASidePanelController.h"
#import "UIViewController+JASidePanel.h"

@interface MySidePanelViewController : JASidePanelController

@end
