//
//  OoredoReports-Bridging-Header.h
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/3/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

#ifndef OoredoReports_Bridging_Header_h
#define OoredoReports_Bridging_Header_h

#import "UIViewController+JASidePanel.h"
#import "JASidePanelController.h"
#import "MySidePanelViewController.h"
#endif /* OoredoReports_Bridging_Header_h */
