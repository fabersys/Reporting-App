//
//  InputViewController.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/2/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import Foundation
import UIKit

class InputViewController: UIViewController {

    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var registerButton: UIButton!
    var username = ""
    var password = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UserUtils.setUserLogged(false)
//        let clr = UIColor.lightGrayColor()
//        input.attributedPlaceholder = NSAttributedString(string: "Mobile Number",attributes: [NSForegroundColorAttributeName:clr])
//        
//        let mNum = UserUtils.MobileNum()
//        if ( mNum != ""){
//            input.text = mNum
//            registerButton.setTitle("Confirm Mobile Number!", forState: .Normal)
//        }
//        
//        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(InputViewController.tapped))
//        self.view.addGestureRecognizer(tapGesture)
        

    }
    func  tapped()
    {
        input.resignFirstResponder()
    }
    
    @IBAction func registerClicked(_ sender: AnyObject) {
        
        var showError = false
        if (!(input.text?.isEmpty)!){
            let num = Int(input.text!)
            if num == nil {
                showError = true
                
            }
        }else {
            showError = true
        }
        if showError {
            let alertController = UIAlertController(title: "Error",
                                                    message: "Enter a valid number",
                                                    preferredStyle: .alert)
            alertController.view.backgroundColor=UIColor.white
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
            
        }else {
            UserUtils.saveMobileNum(input.text!)
            let defaults = UserDefaults.standard
            let deviceToken:String=defaults.string(forKey: "deviceToken")!
            if self.username != "" && self.password != "" {
                ORCoreAPI.sharedAPI.mapDevice(self.username, Password:self.password, DeviceId: deviceToken, MobileNumber: input.text!, DeviceOS: "iOS"+UIDevice.currentDevice().systemVersion, DeviceVersion: UIDevice.currentDevice().model) { (json) ->Void in
                        print("**Map Device **",json)
                        if(json != nil ){
                            if json["Message"].stringValue == "Success" {
                                
                                UserUtils.setUserMapped(true)
                                
                                let alertController = UIAlertController(title: "Success",
                                                                        message: "Activation link sent to email, please activate and login again.", preferredStyle: .Alert)
                                let cancelAction = UIAlertAction(title: "Ok", style: .Cancel) { (action) in
                                    
                                    let sidepanelvc = self.presentingViewController as! MySidePanelViewController
                                    let navvc = sidepanelvc.centerPanel as! UINavigationController
                                    let reportVc = navvc.topViewController as! ReportViewController
                                    reportVc.shouldMap = false
                                    self.navigationController?.pushViewController(reportVc, animated: true)
                                }
                                alertController.addAction(cancelAction)
                               // dispatch_async(dispatch_get_main_queue(), {
                                    self.presentViewController(alertController, animated: true, completion: nil)
                               // })
                            }else {
                                let alertController = UIAlertController(title: "Failed",
                                                                        message: "Device failed to register. Please try again.", preferredStyle: .Alert)
                                let cancelAction = UIAlertAction(title: "Ok", style: .Cancel) { (action) in
                                    let sidepanelvc = self.presentingViewController as! MySidePanelViewController
                                    let navvc = sidepanelvc.centerPanel as! UINavigationController
                                    let reportVc = navvc.topViewController as! ReportViewController
                                    reportVc.shouldMap = false
                                    self.navigationController?.pushViewController(reportVc, animated: true)
                                }
                                alertController.addAction(cancelAction)
                                dispatch_async(dispatch_get_main_queue(), {
                                    self.presentViewController(alertController, animated: true, completion: nil)
                                })
                            }
                        }
                }
            }
            /*
            let sidepanelvc = self.presentingViewController as! MySidePanelViewController
            let navvc = sidepanelvc.centerPanel as! UINavigationController
            let reportVc = navvc.topViewController as! ReportViewController
            reportVc.shouldMap = false
            self.dismissViewControllerAnimated(true, completion: nil)
            */
            
        }
       
    }
    
}
