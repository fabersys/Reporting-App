//
//  MenuViewController.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/2/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let v:UIView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 1))
        tableView.tableFooterView = v

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 { return 0 }
        
        return 55.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
         let  headerCell = tableView.dequeueReusableCell(withIdentifier: "headerCell")
        return headerCell
    }
    
     func numberOfSectionsInTableView(_ tableView: UITableView) -> Int {
        
        return 2
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 { return 3 }
        
        return 1
        
    }
    
    func tableView(_ tableView: UITableView!, heightForRowAtIndexPath indexPath: IndexPath!) -> CGFloat {
        
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "menucell", for: indexPath)
        
         let imgV:UIImageView = cell.viewWithTag(10) as! UIImageView
         let lbl:UILabel = cell.viewWithTag(20) as! UILabel
        if indexPath.section == 0 {
           
            if indexPath.row == 0 {
                
                imgV.image = UIImage(named:"camera.png")
                lbl.text = "Toggle Daily Graphs"
            } else if indexPath.row == 1 {
                
                imgV.image = UIImage(named:"picture.png")
                lbl.text = "Toggle Monthly Graphs"
            }else {
                
                imgV.image = UIImage(named:"play.png")
                lbl.text = "Toggle Yearly Graphs"
            }
        } else {
            lbl.text = "Sign Out"
            imgV.image = UIImage(named:"share.png")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAtIndexPath indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: false)
        
        
    }


}
