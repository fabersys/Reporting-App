//
//  ResetViewController.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/9/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import UIKit

class ResetViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var mobileNumtf: UITextField!
    @IBOutlet weak var newPasswordtf: UITextField!
    @IBOutlet weak var oldPasswordtf: UITextField!
    @IBOutlet weak var userIdtf: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        userIdtf

        // Do any additional setup after loading the view.
    }

    @IBAction func resetClicked(_ sender: AnyObject) {
        ORCoreAPI.sharedAPI.resetPassword(self.userIdtf.text!, OldPassword:self.oldPasswordtf.text!, NewPassword:self.newPasswordtf.text!, MobileNo:self.mobileNumtf.text!, completion: { (json) ->Void in
            print("**Reset Password **",json)
            if(json != nil ){
                print("json", json)
                }
            })
        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder();
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    

}
