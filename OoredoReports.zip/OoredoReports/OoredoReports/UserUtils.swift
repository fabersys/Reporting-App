//
//  UserUtils.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/2/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import UIKit


class UserUtils: NSObject {
    
    class func isUserMapped() -> Bool{
        return UserDefaults.standard.bool(forKey: USER_MAPPED)
    }
    
    class func isUserLogged() -> Bool{
        return UserDefaults.standard.bool(forKey: USER_LOGGED)
    }
    class func setUserMapped(_ yesno : Bool) {
        UserDefaults.standard.set(yesno, forKey: USER_MAPPED)
    }
    
    class func setUserLogged(_ yesno : Bool) {
        UserDefaults.standard.set(yesno, forKey: USER_LOGGED)
    }
    class func saveMobileNum(_ mobileNum: String){
        let data = mobileNum.data(using: String.Encoding.utf8)
        UserDefaults.standard.set(data, forKey: USER_MOBILE_NUM)
        UserDefaults.standard.synchronize()
    }
    class func isInitialLogin() -> Bool{
        return UserDefaults.standard.bool(forKey: USER_FIRST_LOGIN)
    }
    class func setInitialLogin(_ yesno : Bool) {
        UserDefaults.standard.set(yesno, forKey: USER_FIRST_LOGIN)
    }
    class func MobileNum() -> String {
        
        if let d:Data =  UserDefaults.standard.object(forKey: USER_MOBILE_NUM) as? Data {
            
            if  let  str = NSString(data: d, encoding: String.Encoding.utf8.rawValue){
                return str as String
            } else {
                return ""
            }
        }
        return ""
    }
    

}
