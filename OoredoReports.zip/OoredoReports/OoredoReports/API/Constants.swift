//
//  Constants.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 7/2/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import Foundation

let USER_MAPPED = "UserMapped"
let USER_REGISTERED = "UserRegistered"
let USER_LOGGED = "UserLogged"
let USER_MOBILE_NUM = "UserMobileNumber"
let USER_FIRST_LOGIN = "UserInitialLogin"