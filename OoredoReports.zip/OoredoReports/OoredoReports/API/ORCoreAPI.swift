//
//  ORCoreAPI.swift
//  OoredoReports
//
//  Created by Kiranpal Reddy Gurijala on 5/21/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import Foundation
import SwiftyJSON

typealias orAPIResponse = (JSON?, NSError?) -> Void
class ORCoreAPI {
    
    static let sharedAPI = ORCoreAPI()
    
    let apiHost                                = "http://52.32.241.59/ORAPINEW/"
    let apiCurrentDayReports                   = "api/Reports/CD"
    let apiCurrentMonthReports                 = "api/Reports/CM"
    let apiCurrentYearReports                 = "api/Reports/CY"
    let apiDashboardSummary                    = "api/Dashboard/Summary/"
    let apiLMVsCMTD                            = "lmvscmtd"
    let apiMapUser                             = "api/User/mapdevice"
    let apiUserResetPassword                   = "api/User/resetpassword"
    let apiUserForgotPassword                  = "api/User/forgotpassword"
    let apiUnMapUser                           = "api/User/unmapuser"
    let apiAuthentication                      = "api/Authentication"
    
    
    func getCurrentDayReports(_ completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiCurrentDayReports)"
        print("getCurrentDayReports",url)
        makeHTTPRequest(url, completion: { json, error in
            if let currentJSON = json {
                completion(currentJSON as JSON)
            } else {
                // handle error
                print("Current Day Reports get error is", error)
            }
        })
    }
    
    func getCurrentMonthReports(_ completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiCurrentMonthReports)"
        print("getCurrentMonthReports",url)
        makeHTTPRequest(url, completion: { json, error in
            if let currentJSON = json {
                completion(currentJSON as JSON)
            } else {
                // handle error
                print("Current Month Reports get error is", error)
            }
        })
    }
    
    func getCurrentYearReports(_ completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiCurrentYearReports)"
        print("apiCurrentYearReports",url)
        makeHTTPRequest(url, completion: { json, error in
            if let currentJSON = json {
                completion(currentJSON as JSON)
            } else {
                // handle error
                print("Current Month Reports get error is", error)
            }
        })
    }

    func getYearMonthDashboardSummary(_ year:String, month:String, completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiDashboardSummary)\(year)/\(month)"
        print("getYearMonthDashboardSummary",url)
        makeHTTPRequest(url, completion: { json, err in
            if let currentJSON = json {
                //debugPrint(currentJSON, url)
                completion(currentJSON as JSON)
            } else {
                // handle error
            }
        })

    }
    func getLMVsCMTDReports(_ completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiDashboardSummary)\(apiLMVsCMTD)"
        print("getLMVsCMTDReports", url)
        makeHTTPRequest(url, completion: { json, err in
            if let currentJSON = json {
                //debugPrint(currentJSON, url)
                completion(currentJSON as JSON)
            } else {
                // handle error
            }
        })
    }
    
    func mapDevice(_ UserId:String, Password:String, DeviceId:String, MobileNumber:String, DeviceOS:String, DeviceVersion:String, completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiMapUser)"
        ///\(UserId)/\(Password)/\(DeviceId)/\(MobileNumber)/\(DeviceOS)/\(DeviceVersion)
        print("mapDevice URL",url)
        print("DeviceId", DeviceId)
        let parameters = ["UserId":UserId, "Password":Password,"DeviceId":DeviceId, "MobileNumber":MobileNumber, "DeviceOS":DeviceOS, "DeviceVersion":DeviceVersion] as Dictionary<String, String>
        makeHTTPRequestWithJSONBody(url, method: "POST", parameters:parameters, completion: { json, err in
            
            if let currentJSON = json {
                completion(currentJSON as JSON)
                print(json)
            } else {
                // handle error
                let str = "jsonString"
                let dataFromString = str.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
                let json = JSON(data: dataFromString!)
                 completion(json)
                print("Map device setting error is", err)
            }
        })

    }
    
    func resetPassword(_ UserId:String, OldPassword:String, NewPassword:String, MobileNo:String, completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiUserResetPassword)"
        print("resetPassword URL",url)
        let parameters = ["UserId":UserId, "OldPassword":OldPassword,"NewPassword":NewPassword, "MobileNo":MobileNo] as Dictionary<String, String>
        makeHTTPRequestWithJSONBody(url, method: "POST", parameters:parameters, completion: { json, err in
            
            if let currentJSON = json {
                completion(currentJSON as JSON)
                print(json)
                if let httpResponse = json as? NSHTTPURLResponse {
                    if let contentType = httpResponse.allHeaderFields["ErrorCode"] as? String {
                        // use contentType here
                        print("contentType",contentType)
                        completion("reset")
                    }
                }
            } else {
                // handle error
                let str = "jsonString"
                let dataFromString = str.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
                let json = JSON(data: dataFromString!)
                completion(json)
                print("Password setting error is", err)
            }
        })
    }
    
    func forgotPassword(_ UserId:String, completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiUserForgotPassword)"
        print("forgotPassword URL",url)
        let parameters = ["UserId":UserId] as Dictionary<String, String>
        makeHTTPRequestWithJSONBody(url, method: "POST", parameters:parameters, completion: { json, err in
            
            if let currentJSON = json {
                completion(currentJSON as JSON)
                print(json)
                if let httpResponse = json as? NSHTTPURLResponse {
                    if let contentType = httpResponse.allHeaderFields["ErrorCode"] as? String {
                        // use contentType here
                        print("Forgot Password ContentType",contentType)
                        completion("reset")
                    }
                }
            } else {
                // handle error
                let str = "jsonString"
                let dataFromString = str.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
                let json = JSON(data: dataFromString!)
                completion(json)
                print("**Forgot Password** error is", err)
            }
        })
    }
    
    func unMapUser(_ completion: (JSON) -> Void) {
        let url = "\(apiHost)\(apiUnMapUser)"
        let parameters = [1]
        print("unMap Device URL",url)
        makeHTTPRequest(url, completion: { json, err in
            if let currentJSON = json {
                //debugPrint(currentJSON, url)
                completion(currentJSON as JSON)
            } else {
                // handle error
            }
        })
    }
    
    func loginAuthentication(_ UserId:String, Password:String, DeviceId:String, completion: @escaping (String, NSError?) -> Void){
        let url = "\(apiHost)\(apiAuthentication)/"
        print(url)
        let loginString = NSString(format: "%@:%@:%@", UserId, Password, DeviceId)
        let loginData = loginString.data(using: String.Encoding.utf8.rawValue)!
        let base64LoginString = loginData.base64EncodedString(options: NSData.Base64EncodingOptions(rawValue: 0))
        print("base64LoginString", base64LoginString)
        let request = NSMutableURLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        //let urlConnection = NSURLConnection(request: request, delegate: self)
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: {data, response, error -> Void in
            if let currentData = data {
                //dispatch_async(dispatch_get_main_queue()) {
                let json:JSON? = JSON(data: currentData)
                print("json",json)
                if let currentJSON = json {
                    if (currentJSON != nil) {
                        //print("currentJSON",currentJSON)
                        completion((json?.stringValue)!, error)
                    } else {
                        //let jsonString:String = (NSString(data: currentData, encoding: NSUTF8StringEncoding) as! String)
                        //let newString = jsonString.stringByReplacingOccurrencesOfString("NaN", withString: "0")
                        //print("jsonString",newString)
                        if let httpResponse = response as? HTTPURLResponse {
                            if let contentType = httpResponse.allHeaderFields["ErrorCode"] as? String {
                                // use contentType here
                                print("contentType",contentType)
                                completion(contentType, error)
                            }
                        }
//                        if let dataFromString = newString.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false) {
//                            let singleJSON:JSON? = JSON(data: dataFromString)
//                            
//                            completion(singleJSON, error)
//                        } else {
//                            completion(nil, error)
//                        }
                    }
                } else {
                    
                    completion("Error", error)
                }
                //}
            } else {
                completion("Error", error)
            }
        })
        task.resume()

    }
    func makeHTTPRequest(_ path:String, completion:orAPIResponse) {
        makeHTTPRequest(path, method: "GET", completion: completion)
    }
    
    
    func makeHTTPRequestWithJSONBody(_ path:String, method:String, parameters:Dictionary<String, String>, completion:orAPIResponse) {
        let request = NSMutableURLRequest(url: URL(string: path)!)
        request.httpMethod = method
        let session = URLSession.shared
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        //request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options: [])
        
        let task = session.dataTask(with: request, completionHandler: { data, response, error in
            guard data != nil else {
                print("no data found: \(error)")
                completion(nil, error)
                return
            }
            
            do {
                let json:JSON? = JSON(data: data!)
                if let currentJSON = json {
                    if (currentJSON[0] != nil) {
                        print("currentJSON",currentJSON)
                        completion(currentJSON, error)
                    } else {
                        let jsonString:String = (NSString(data: data!, encoding: String.Encoding.utf8) as! String)
                        let newString = jsonString.replacingOccurrences(of: "NaN", with: "0")
                        //print("jsonString",newString)
                        if let dataFromString = newString.data(using: String.Encoding.utf8, allowLossyConversion: false) {
                            let singleJSON:JSON? = JSON(data: dataFromString)
                            print("singleJSON",singleJSON)
                            completion(singleJSON, error)
                        } else {
                            completion(nil, error)
                        }
                    }
                }

            } catch let parseError {
                print(parseError)// Log the error thrown by `JSONObjectWithData`
                let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8)
                print("Error could not parse JSON: '\(jsonStr)'")
            }
        }) 
        
        task.resume()
    }
    func makeHTTPRequest(_ path:String, method:String, completion:orAPIResponse) {
        let request = NSMutableURLRequest(url: URL(string: path)!)
        request.httpMethod = method
        let session = URLSession.shared
        
        let task = session.dataTask(with: request, completionHandler: {data, response, error -> Void in
            if let currentData = data {
                //dispatch_async(dispatch_get_main_queue()) {
                let json:JSON? = JSON(data: currentData)
                print("json",json)
                if let currentJSON = json {
                    if (currentJSON[0] != nil) {
                        //print("currentJSON",currentJSON)
                        completion(currentJSON, error)
                    } else {
                        let jsonString:String = (NSString(data: currentData, encoding: String.Encoding.utf8) as! String)
                        let newString = jsonString.replacingOccurrences(of: "NaN", with: "0")
                        //print("jsonString",newString)
                        if let dataFromString = newString.data(using: String.Encoding.utf8, allowLossyConversion: false) {
                            let singleJSON:JSON? = JSON(data: dataFromString)
                            
                            completion(singleJSON, error)
                        } else {
                            completion(nil, error)
                        }
                    }
                } else {
                    completion(nil, error)
                }
                //}
            } else {
                completion(nil, error)
            }
        })
        task.resume()
    }
}
