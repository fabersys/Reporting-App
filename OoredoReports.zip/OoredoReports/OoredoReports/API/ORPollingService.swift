//
//  ORPollingService.swift
//  OoredoReports
//
//  Created by Kiranpal Reddy Gurijala on 6/6/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import Foundation
import SwiftyJSON


class ORPollingService {
    static let sharedService = ORPollingService()
    var lmVscmReport:[String:(Float,Float)] = [String:(Float,Float)]()
    var CDHourlySummary:[(Int,Double)] = [(Int,Double)]()
    var LDHourlySummary:[(Int,Double)] = [(Int,Double)]()
    
    var cdVsldReport:[Int:[Double:Double]] = [Int:[Double:Double]]()
    
    var CDServiceWiseSummary:[String:Double] = [String:Double]()
    
    var CMDailySummary:[(Date,Float)] = [(Date,Float)]()
    var CMDailySummaryDouble:[(Date,Double)] = [(Date,Double)]()
    var LMDailySummary:[(Date,Float)] = [(Date,Float)]()
    var LMDailySummaryDouble:[(Date,Double)] = [(Date,Double)]()
    
    var cmVslmReport:[String:[Double:Double]] = [String:[Double:Double]]()
    var cmVslmReportDouble:[Int:[Double:Double]] = [Int:[Double:Double]]()
    
    
    var CMServiceWiseSummary:[String:Double] = [String:Double]()
    
    var CYMonthlySummary:[(Int,Float)] = [(Int,Float)]()
    var LYMonthlySummary:[(Int,Float)] = [(Int,Float)]()
    var CYServiceWiseSummary:[String:Double] = [String:Double]()
    
    var cyVslyReport:[Int:[Double:Double]] = [Int:[Double:Double]]()
    
    var CDTotal:Int = 0
    var CMTotal:Int = 0
    var CYTotal:Int = 0
    
    var DoDRevenue:Float = 0.0
    var DoDPercentage:Float = 0.0
    var CDProjectedRevenue:Int = 0
    var CDPreviouseDayRevenue:String = ""
    
    var MoMRevenue:Float = 0.0
    var MoMPercentage:Float = 0.0
    var CMProjectedRevenue:Int = 0
    var CMPreviouseDayRevenue:String = ""
    
    var YoYRevenue:Float = 0.0
    var YoYPercentage:Float = 0.0
    var CYProjectedRevenue:Int = 0
    var CYPreviouseDayRevenue:String = ""
    
    
    func requestLMVsCMTDReports() {
        var lmReportValue:[String:Float] = [String:Float]()
        var cmReportValue:[String:Float] = [String:Float]()
        ORCoreAPI.sharedAPI.getLMVsCMTDReports() { (json:JSON) ->
            Void in
            for subJson in json["Data"].arrayValue {
                let day:String = "Day"+subJson["Day"].stringValue
                let lmValue:Float = subJson["LmValue"].floatValue
                let cmValue:Float = subJson["CmValue"].floatValue
                lmReportValue[day] = lmValue
                cmReportValue[day] = cmValue
                self.lmVscmReport[day] = (lmValue,cmValue)
            }
            //print("LMVsCMTDReports",self.lmVscmReport)
            
        }

    }
    
    func requestCurrentDayReports(){
        ORCoreAPI.sharedAPI.getCurrentDayReports() { (json:JSON) ->
            Void in
            //print("getCurrentDayReports",json["Data"]["CDServiceWiseSummary"])
            print("getCurrentDayReports",json["Data"])
            print("getCurrentDayReports - CDTotal", json["Data"]["CDTotal"])
            print("getCurrentDayReports - ProjectedRevenue", json["Data"]["ProjectedRevenue"].stringValue)
            print("getCurrentDayReports - DoDRevenue",json["Data"]["DoDRevenue"])
            print("getCurrentDayReports - DoDPercentage",json["Data"]["DoDPercentage"])
            print("getCurrentDayReports - PreviousDayRevenue",json["Data"]["PreviouseDayRevenue"])
            
            self.CDTotal=json["Data"]["CDTotal"].intValue
            self.CDProjectedRevenue = json["Data"]["ProjectedRevenue"].intValue
            self.DoDPercentage = json["Data"]["DoDPercentage"].floatValue
            self.DoDRevenue = json["Data"]["DoDRevenue"].floatValue
            
            var cdSummaryHourlyRaw:[Int:Double] = [Int:Double]()
            for subCDHourlySummaryJson in json["Data"]["CDHourlySummary"].arrayValue {
                let trxHourCD:Int = subCDHourlySummaryJson["TrxHour"].intValue
                let revenueCD:Double = subCDHourlySummaryJson["Revenue"].doubleValue
                cdSummaryHourlyRaw[trxHourCD] = revenueCD
            }
            self.CDHourlySummary = cdSummaryHourlyRaw.sort{ return $0.0 < $1.0 }
            var ldSummaryHourlyRaw:[Int:Double] = [Int:Double]()
            for subLDHourlySummaryJson in json["Data"]["LDHourlySummary"].arrayValue {
                let trxHourLD:Int = subLDHourlySummaryJson["TrxHour"].intValue
                let revenueLD:Double = subLDHourlySummaryJson["Revenue"].doubleValue
                ldSummaryHourlyRaw[trxHourLD] = revenueLD
            }
            self.LDHourlySummary = ldSummaryHourlyRaw.sort{ return $0.0 < $1.0 }
            var cdVsldReportRaw:[Int:[Double:Double]] = [Int:[Double:Double]]()
            var cdSummaryHourlyRawKeys:[Int]=Array(cdSummaryHourlyRaw.keys)
            var cdSummaryHourlyRawValues:[Double]=Array(cdSummaryHourlyRaw.values)
            var ldSummaryHourlyRawValues:[Double]=Array(ldSummaryHourlyRaw.values)
            
            for j in 0..<cdSummaryHourlyRaw.count{
                
                cdVsldReportRaw[Int(cdSummaryHourlyRawKeys[j])] = [Double(cdSummaryHourlyRawValues[j]):Double(ldSummaryHourlyRawValues[j])]
            }
            
            var cdVsldReportX:[(Int,[Double:Double])] = [(Int,[Double:Double])]()
            cdVsldReportX = cdVsldReportRaw.sort{ return $0.0 < $1.0}
            
            for i in 0..<cdVsldReportX.count{
                self.cdVsldReport[cdVsldReportX[i].0] = cdVsldReportX[i].1
            }

            for subCDServiceWiseSummaryJson in json["Data"]["CDServiceWiseSummary"].arrayValue {
                let serviceName:String = subCDServiceWiseSummaryJson["ServiceName"].stringValue
                let revenueSummary:Double = subCDServiceWiseSummaryJson["Revenue"].doubleValue
                self.CDServiceWiseSummary[serviceName] = revenueSummary
            }
            print("cdVsldReport", self.cdVsldReport)
        }
    }
    


    
    func requestCurrentMonthReports(){
        ORCoreAPI.sharedAPI.getCurrentMonthReports() { (json:JSON) ->
            Void in
            
            print("getCurrentMonthReports",json["Data"])
            print("getCurrentMonthReports - CMTotal", json["Data"]["CMTotal"])
            print("getCurrentMonthReports - ProjectedRevenue", json["Data"]["ProjectedRevenue"])
            print("getCurrentMonthReports - MoMRevenue",json["Data"]["MoMRevenue"])
            print("getCurrentMonthReports - MoMPercentage",json["Data"]["MoMPercentage"])
            print("getCurrentMonthReports - PreviousMonthRevenue",json["Data"]["PreviousMonthRevenue"])
            
            self.CMTotal=json["Data"]["CMTotal"].intValue
            self.CMProjectedRevenue = json["Data"]["ProjectedRevenue"].intValue
            self.MoMPercentage = json["Data"]["MoMPercentage"].floatValue
            self.MoMRevenue = json["Data"]["MoMRevenue"].floatValue
            var cmSummaryHourlyRaw:[NSDate:Float] = [NSDate:Float]()
            for subCMHourlySummaryJson in json["Data"]["CMDailySummary"].arrayValue {
                let date:String = subCMHourlySummaryJson["TransactionDate"].stringValue
                let dateFormatter = NSDateFormatter()
                ////dateFormatter.dateFormat = date
               // dateFormatter.timeZone = NSTimeZone(abbreviation: "UTC");
                dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                let trxHourCM:NSDate = dateFormatter.dateFromString(date)!
                let revenueCM:Float = subCMHourlySummaryJson["Revenue"].floatValue
                cmSummaryHourlyRaw[trxHourCM] = revenueCM
            }
            self.CMDailySummary = cmSummaryHourlyRaw.sort{ return $0.0.timeIntervalSince1970 < $1.0.timeIntervalSince1970 }
            var lmSummaryHourlyRaw:[NSDate:Float] = [NSDate:Float]()
            for subLMHourlySummaryJson in json["Data"]["LMDailySummary"].arrayValue {
                let date:String = subLMHourlySummaryJson["TransactionDate"].stringValue
                let dateFormatter = NSDateFormatter()
                ////dateFormatter.dateFormat = date
                //dateFormatter.timeZone = NSTimeZone(abbreviation: "UTC");
                dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                let trxHourLM:NSDate = dateFormatter.dateFromString(date)!
                let revenueLM:Float = subLMHourlySummaryJson["Revenue"].floatValue
                lmSummaryHourlyRaw[trxHourLM] = revenueLM
            }
            self.LMDailySummary = lmSummaryHourlyRaw.sort{ return $0.0.timeIntervalSince1970 < $1.0.timeIntervalSince1970 }
            
            var cmVslmReportRaw:[String:[Double:Double]] = [String:[Double:Double]]()
            var cmSummaryHourlyRawKeys:[NSDate]=Array(cmSummaryHourlyRaw.keys)
            var cmSummaryHourlyRawValues:[Float]=Array(cmSummaryHourlyRaw.values)
            var lmSummaryHourlyRawValues:[Float]=Array(lmSummaryHourlyRaw.values)
            
            for j in 0..<cmSummaryHourlyRaw.count{
                
                cmVslmReportRaw[String(cmSummaryHourlyRawKeys[j])] = [Double(cmSummaryHourlyRawValues[j]):Double(lmSummaryHourlyRawValues[j])]
            }
            
            var cmVslmReportX:[(String,[Double:Double])] = [(String,[Double:Double])]()
            cmVslmReportX = cmVslmReportRaw.sort{ return $0.0 < $1.0}
            
            for i in 0..<cmVslmReportX.count{
                self.cmVslmReport[cmVslmReportX[i].0] = cmVslmReportX[i].1
            }
            for subCMServiceWiseSummaryJson in json["Data"]["CMServiceWiseSummary"].arrayValue {
                let serviceName:String = subCMServiceWiseSummaryJson["ServiceName"].stringValue
                let revenueSummary:Double = subCMServiceWiseSummaryJson["Revenue"].doubleValue
                self.CMServiceWiseSummary[serviceName] = revenueSummary
            }
            
        }
    }
    
    func requestCurrentMonthReportsDouble(){
        ORCoreAPI.sharedAPI.getCurrentMonthReports() { (json:JSON) ->
            Void in
    
            print("getCurrentMonthReports",json["Data"])
            print("getCurrentMonthReports - CMTotal", json["Data"]["CMTotal"])
            print("getCurrentMonthReports - ProjectedRevenue", json["Data"]["ProjectedRevenue"])
            print("getCurrentMonthReports - MoMRevenue",json["Data"]["MoMRevenue"])
            print("getCurrentMonthReports - MoMPercentage",json["Data"]["MoMPercentage"])
            print("getCurrentMonthReports - PreviousMonthRevenue",json["Data"])
            
            self.CMTotal=json["Data"]["CMTotal"].intValue
            self.CMProjectedRevenue = json["Data"]["ProjectedRevenue"].intValue
            self.MoMPercentage = json["Data"]["MoMPercentage"].floatValue
            self.MoMRevenue = json["Data"]["MoMRevenue"].floatValue
            var cmSummaryHourlyRaw:[NSDate:Double] = [NSDate:Double]()
            for subCMHourlySummaryJson in json["Data"]["CMDailySummary"].arrayValue {
                let date:String = subCMHourlySummaryJson["TransactionDate"].stringValue
                let dateFormatter = NSDateFormatter()
                ////dateFormatter.dateFormat = date
                // dateFormatter.timeZone = NSTimeZone(abbreviation: "UTC");
                dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                let trxHourCM:NSDate = dateFormatter.dateFromString(date)!
                let revenueCM:Double = subCMHourlySummaryJson["Revenue"].doubleValue
                cmSummaryHourlyRaw[trxHourCM] = revenueCM
            }
            self.CMDailySummaryDouble = cmSummaryHourlyRaw.sort{ return $0.0.timeIntervalSince1970 < $1.0.timeIntervalSince1970 }
            var lmSummaryHourlyRaw:[NSDate:Double] = [NSDate:Double]()
            for subLMHourlySummaryJson in json["Data"]["LMDailySummary"].arrayValue {
                let date:String = subLMHourlySummaryJson["TransactionDate"].stringValue
                let dateFormatter = NSDateFormatter()
                ////dateFormatter.dateFormat = date
                //dateFormatter.timeZone = NSTimeZone(abbreviation: "UTC");
                dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                let trxHourLM:NSDate = dateFormatter.dateFromString(date)!
                let revenueLM:Double = subLMHourlySummaryJson["Revenue"].doubleValue
                lmSummaryHourlyRaw[trxHourLM] = revenueLM
            }
            self.LMDailySummaryDouble = lmSummaryHourlyRaw.sort{ return $0.0.timeIntervalSince1970 < $1.0.timeIntervalSince1970 }
            
            var cmVslmReportRaw:[String:[Double:Double]] = [String:[Double:Double]]()
            var cmSummaryHourlyRawKeys:[NSDate]=Array(cmSummaryHourlyRaw.keys)
            var cmSummaryHourlyRawValues:[Double]=Array(cmSummaryHourlyRaw.values)
            var lmSummaryHourlyRawValues:[Double]=Array(lmSummaryHourlyRaw.values)
            
            for j in 0..<cmSummaryHourlyRaw.count{
                
                cmVslmReportRaw[String(cmSummaryHourlyRawKeys[j])] = [Double(cmSummaryHourlyRawValues[j]):Double(lmSummaryHourlyRawValues[j])]
            }
            
            var cmVslmReportX:[(String,[Double:Double])] = [(String,[Double:Double])]()
            cmVslmReportX = cmVslmReportRaw.sort{ return $0.0 < $1.0}
            for i in 0..<cmVslmReportX.count{
                let range = cmVslmReportX[i].0.startIndex.advancedBy(8)..<cmVslmReportX[i].0.endIndex.advancedBy(-15)
                let substringe = Int(cmVslmReportX[i].0[range])
                self.cmVslmReportDouble[substringe!] = cmVslmReportX[i].1
            }
            for subCMServiceWiseSummaryJson in json["Data"]["CMServiceWiseSummary"].arrayValue {
                let serviceName:String = subCMServiceWiseSummaryJson["ServiceName"].stringValue
                let revenueSummary:Double = subCMServiceWiseSummaryJson["Revenue"].doubleValue
                self.CMServiceWiseSummary[serviceName] = revenueSummary
            }
        }
    }
    func requestCurrentYearReports(){
        ORCoreAPI.sharedAPI.getCurrentYearReports() { (json:JSON) ->
            Void in
            
            print("getCurrentYearReports",json["Data"])
            print("getCurrentYearReports - CMTotal", json["Data"]["CYTotal"])
            print("getCurrentYearReports - ProjectedRevenue", json["Data"]["ProjectedRevenue"])
            print("getCurrentYearReports - MoMRevenue",json["Data"]["YoYRevenue"])
            print("getCurrentYearReports - MoMPercentage",json["Data"]["YoYPercentage"])
            print("getCurrentyearReports - PreviousMonthRevenue",json["Data"]["PreviousyearRevenue"])
            
            self.CYTotal=json["Data"]["CYTotal"].intValue
            self.CYProjectedRevenue = json["Data"]["ProjectedRevenue"].intValue
            self.YoYPercentage = json["Data"]["YoYPercentage"].floatValue
            self.YoYRevenue = json["Data"]["YoYRevenue"].floatValue
            var cySummaryMonthlyRaw:[Int:Float] = [Int:Float]()
            for subCYMonthlySummaryJson in json["Data"]["CYMonthlySummary"].arrayValue {
                let date:String = subCYMonthlySummaryJson["Month"].stringValue
                let dateFormatter = NSDateFormatter()
                dateFormatter.dateFormat = "MMM"
                let trxMonthlyCY:NSDate = dateFormatter.dateFromString(date)!
                let timeStampMonthlyCY = trxMonthlyCY.timeIntervalSince1970
                let revenueCY:Float = subCYMonthlySummaryJson["Revenue"].floatValue
                cySummaryMonthlyRaw[Int(timeStampMonthlyCY)] = revenueCY
            }
            self.CYMonthlySummary = cySummaryMonthlyRaw.sort{ return $0.0 < $1.0 }
            var lySummaryMonthlyRaw:[NSDate:Float] = [NSDate:Float]()
            for subLYMonthlySummaryJson in json["Data"]["LYMonthlySummary"].arrayValue {
                let date:String = subLYMonthlySummaryJson["Month"].stringValue
                let dateFormatter = NSDateFormatter()
                dateFormatter.dateFormat = "MMM"
                let trxHourLM:NSDate = dateFormatter.dateFromString(date)!
                let revenueLM:Float = subLYMonthlySummaryJson["Revenue"].floatValue
                lySummaryMonthlyRaw[trxHourLM] = revenueLM
            }
            self.LMDailySummary = lySummaryMonthlyRaw.sort{ return $0.0.timeIntervalSince1970 < $1.0.timeIntervalSince1970 }
            
            var cyVslyReportRaw:[Int:[Double:Double]] = [Int:[Double:Double]]()
            var cySummaryMonthlyRawKeys:[Int]=Array(cySummaryMonthlyRaw.keys)
            var cySummaryMonthlyRawValues:[Float]=Array(cySummaryMonthlyRaw.values)
            var lySummaryMonthlyRawValues:[Float]=Array(cySummaryMonthlyRaw.values)
            
            for j in 0..<cySummaryMonthlyRaw.count{
                print("cySummaryMonthlyRawKeys[j]", cySummaryMonthlyRawKeys[j])
                cyVslyReportRaw[Int(cySummaryMonthlyRawKeys[j])] = [Double(cySummaryMonthlyRawValues[j]):Double(lySummaryMonthlyRawValues[j])]
            }
            
            var cyVslyReportX:[(Int,[Double:Double])] = [(Int,[Double:Double])]()
            cyVslyReportX = cyVslyReportRaw.sort{ return $0.0 < $1.0}
            
            for i in 0..<cyVslyReportX.count{
                self.cyVslyReport[cyVslyReportX[i].0] = cyVslyReportX[i].1
            }
            for subCYServiceWiseSummaryJson in json["Data"]["CYServiceWiseSummary"].arrayValue {
                let serviceName:String = subCYServiceWiseSummaryJson["ServiceName"].stringValue
                let revenueSummary:Double = subCYServiceWiseSummaryJson["Revenue"].doubleValue
                self.CYServiceWiseSummary[serviceName] = revenueSummary
            }
            
        }

    }
    func requestYearMonthDashboardSummary() {
        print("String(dateMonth)", String(monthDate))
        ORCoreAPI.sharedAPI.getYearMonthDashboardSummary(String(dateYear), month:String(monthDate)) { (json:JSON) ->
            Void in
            print("getYearMonthDashboardSummary",json)
        }
    }
    
    func encryptString(_ inputString:String){
        
    }
    func getOddString(_ inputString:String)->String{
        var returnString: String=""
        for char in inputString.characters {
            for i in 0..<inputString.characters.count{
                if((i+1) % 2 != 0){
                    returnString.append(char);
                }
            }
        }
        return returnString;
    }
    func getEvenString(_ inputString:String)->String{
        var returnString: String=""
        for char in inputString.characters {
            for i in 0..<inputString.characters.count{
                if((i+1) % 2 == 0){
                returnString.append(char);
                }
            }
        }
        return returnString;
    }
    func getShaString(_ inputString:String)->String{
//        let data = inputString.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
//        var digest = [UInt8](repeating: 0, count:Int(CC_SHA1_DIGEST_LENGTH))
//        data.withUnsafeBytes {
//            _ = CC_SHA1($0, CC_LONG(data.count), &digest)
//        }
//        let hexBytes = digest.map { String(format: "%02hhx", $0) }
//        return hexBytes.joined(separator: "")
        return "SHA1"
    }
}
