//
//  ViewController.swift
//  OoredoReports
//
//  Created by Sravani Kuntamukkala on 5/21/16.
//  Copyright © 2016 ooredoo. All rights reserved.
//

import UIKit
import SwiftyJSON


class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var unameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var errorLbl: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = false
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = true
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        let qualityOfServiceClass = QOS_CLASS_BACKGROUND
        let backgroundQueue = dispatch_get_global_queue(qualityOfServiceClass, 0)
        dispatch_async(backgroundQueue, {
            print("This is run on the background queue")
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                print("This is run on the main queue, after the previous code in outer block")
            })
        })
 */
        
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.switchToDashboard()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func signInClicked(_ sender: AnyObject) {
        
       
        
        /*
        let reportsSceneVC:ReportViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MISReportsScene") as! ReportViewController
        
        let navvc = self.sidePanelController.centerPanel as! UINavigationController
       
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            navvc.viewControllers = [reportsSceneVC]
            self.sidePanelController?.showCenterPanelAnimated(true)
        })
        */
        
        
        unameTF.resignFirstResponder()
        passwordTF.resignFirstResponder()
        
        if (unameTF.text!.isEmpty || passwordTF.text!.isEmpty)
        {
            let alertController = UIAlertController(title: "",
                                                    message: "",
                                                    preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            let alertMessageAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Regular", size: 15.0)! ]
            let alertTitleAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Bold", size: 15.0)! ]
            let messageText = NSMutableAttributedString(string: "Please enter the username/password", attributes: alertMessageAttribute)
            let titleText = NSMutableAttributedString(string: "Oops! Empty Field", attributes: alertTitleAttribute)
            alertController.setValue(messageText, forKey: "attributedMessage")
            alertController.setValue(titleText, forKey: "attributedTitle")
            alertController.view.tintColor = UIColor.red
            alertController.view.alpha = 1.0
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
        }
            
        else {
            let defaults = UserDefaults.standard
            let deviceToken:String=defaults.string(forKey: "deviceToken")!
            

            let uname = unameTF.text
            let pwd = passwordTF.text
                    ORCoreAPI.sharedAPI.loginAuthentication(uname!, Password: pwd!, DeviceId: deviceToken, completion: { (json, error) in
                        print("**Login**",json)
                        if (json != "Error"){
                            let errorcode = Int(json)
                            let title = "Login Failed"; var msg = "'"
                            if errorcode == 1 {
                                // category 1 : Invalid Credentails
                                let alertController = UIAlertController(title: title,
                                    message: "", preferredStyle: .alert)
                                let alertAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Regular", size: 15.0)! ]
                                let messageText = NSMutableAttributedString(string: "Invalid Username/Password. Please enter valid credentials", attributes: alertAttribute)
                                alertController.setValue(messageText, forKey: "attributedTitle")
                                alertController.view.tintColor = UIColor.red
                                alertController.view.alpha = 1.0
                                let cancelAction = UIAlertAction(title: "Ok", style: .cancel) { (action) in
                                }
                                alertController.addAction(cancelAction)
                                DispatchQueue.main.async(execute: { () -> Void in
                                    self.present(alertController, animated: true, completion: nil)
                                })

                                
                            } else if errorcode == 2 {
                                // category 2 : User Device Not Mapped
                                let alertController = UIAlertController(title: title,
                                    message: "", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                                }
                                let alertAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Regular", size: 15.0)! ]
                                let messageText = NSMutableAttributedString(string: "Please enter your Mobile Number", attributes: alertAttribute)
                                var phoneNoField:UITextField = UITextField()
                                alertController.addTextField(configurationHandler: {(textField: UITextField!) in
                                    textField.placeholder = ""
                                    textField.isSecureTextEntry = false
                                    phoneNoField = textField
                                })
                                alertController.setValue(messageText, forKey: "attributedTitle")
                                alertController.view.tintColor = UIColor.red
                                alertController.view.alpha = 1.0
                                alertController.addAction(cancelAction)
                                
                                let OKAction = UIAlertAction(title: "Submit", style: .default) { (action) in
                                    
                                    let sidepanelvc = self.presentingViewController as! MySidePanelViewController
                                    let navvc = sidepanelvc.centerPanel as! UINavigationController
                                    let reportVc = navvc.topViewController as! ReportViewController
                                    reportVc.shouldMap = true
                                    reportVc.username = self.unameTF.text!
                                    reportVc.password = pwd!
                                    UserUtils.saveMobileNum(phoneNoField.text!)
                                    let mobileNumber:String = UserUtils.MobileNum()
                                    self.registerClicked(mobileNumber, username: self.unameTF.text!, password: self.passwordTF.text!)
//                                    self.dismissViewControllerAnimated(true, completion: nil)
                                }
                                alertController.addAction(OKAction)
                                DispatchQueue.main.async(execute: {
                                    self.present(alertController, animated: true, completion: nil)
                                })
                                
                                
                            } else if errorcode == 3 {
                                // category 3 : User should be activated
                                let alertController = UIAlertController(title: title,
                                    message: "", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "Ok", style: .cancel) { (action) in
                                }
                                let alertAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Regular", size: 15.0)! ]
                                let messageText = NSMutableAttributedString(string: "Your user Id is not activated. An email has been sent to your registered email, and try again to login after activating user id.", attributes: alertAttribute)
                                alertController.setValue(messageText, forKey: "attributedTitle")
                                alertController.view.tintColor = UIColor.red
                                alertController.view.alpha = 1.0

                                alertController.addAction(cancelAction)
                                DispatchQueue.main.async(execute: { () -> Void in
                                    self.present(alertController, animated: true, completion: nil)
                                })

                                
                            }else if errorcode == 4 {
                                // category 4 : Password should be reset
                                let alertController = UIAlertController(title: title,
                                    message: msg, preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                                }
                                let alertAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Regular", size: 15.0)! ]
                                let messageText = NSMutableAttributedString(string: "Please reset your password to access the app.", attributes: alertAttribute)
                                alertController.setValue(messageText, forKey: "attributedTitle")
                                alertController.view.tintColor = UIColor.red
                                alertController.view.alpha = 1.0

                                alertController.addAction(cancelAction)
                                
                                
                                let OKAction = UIAlertAction(title: "Reset", style: .default) { (action) in
                                    DispatchQueue.main.async(execute: { () -> Void in
                                   //self.dismissViewControllerAnimated(true, completion: nil)
                                    let resetSceneVC:ResetViewController = self.storyboard?.instantiateViewController(withIdentifier: "ResetViewController") as! ResetViewController
                                    //self.navigationController?.pushViewController(resetSceneVC, animated: true)
                                        self.show(resetSceneVC, sender: self)
                                    })
                                }
                                alertController.addAction(OKAction)
                                DispatchQueue.main.async(execute: { () -> Void in
                                    self.present(alertController, animated: true, completion: nil)
                                })
                                
                                

                                
                                
                            }else if errorcode == 5 {
                                // category 5 : User Barred
                                let alertController = UIAlertController(title: title,
                                    message: msg, preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "Ok", style: .cancel) { (action) in
                                }
                                let alertAttribute = [ NSFontAttributeName: UIFont(name: "Exo-Regular", size: 15.0)! ]
                                let messageText = NSMutableAttributedString(string: "Your User Id is barred from using the app.", attributes: alertAttribute)
                                alertController.setValue(messageText, forKey: "attributedTitle")
                                alertController.view.tintColor = UIColor.red
                                alertController.view.alpha = 1.0

                                alertController.addAction(cancelAction)
                                DispatchQueue.main.async(execute: { () -> Void in
                                    self.present(alertController, animated: true, completion: nil)
                                })

                            }else {
                                // Successful login
                                UserUtils.setUserLogged(true)
                                UserUtils.setUserMapped(true)
                                self.dismiss(animated: true, completion: nil)
                            }
    
                            
                        }
                    })

        }
        
        
    }
    
    func registerClicked(_ mobileNumber:String, username:String, password:String) {
        
        var showError = false
        if (!(mobileNumber.isEmpty)){
            let num = Int(mobileNumber)
            if num == nil {
                showError = true
                
            }
        }else {
            showError = true
        }
        if showError {
            let alertController = UIAlertController(title: "Error",
                                                    message: "Enter a valid number",
                                                    preferredStyle: .alert)
            alertController.view.backgroundColor=UIColor.white
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
            
        }else {
            UserUtils.saveMobileNum(mobileNumber)
            let defaults = UserDefaults.standard
            let deviceToken:String=defaults.string(forKey: "deviceToken")!
            if username != "" && password != "" {
                ORCoreAPI.sharedAPI.mapDevice(username, Password:password, DeviceId: deviceToken, MobileNumber: mobileNumber, DeviceOS: "iOS"+UIDevice.currentDevice().systemVersion, DeviceVersion: UIDevice.currentDevice().model) { (json) ->Void in
                    print("**Map Device **",json)
                    if(json != nil ){
                        if json["Message"].stringValue == "Success" {
                            
                            UserUtils.setUserMapped(true)
                            
                            let alertController = UIAlertController(title: "Success",
                                                                    message: "Activation link sent to email, please activate and login again.", preferredStyle: .Alert)
                            let cancelAction = UIAlertAction(title: "Ok", style: .Cancel) { (action) in
                                
                                //self.dismissViewControllerAnimated(true, completion: nil)
                                /*
                                 let sidepanelvc = self.presentingViewController as! MySidePanelViewController
                                 let navvc = sidepanelvc.centerPanel as! UINavigationController
                                 let reportVc = navvc.topViewController as! ReportViewController
                                 let reportsSceneVC:ReportViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MISReportsScene") as! ReportViewController
                                 reportVc.shouldMap = false */
                                //                                let loginVC = self.storyboard?.instantiateViewControllerWithIdentifier("ViewController") as! LoginViewController
                                //                                dispatch_async(dispatch_get_main_queue(), {
                                //                                    self.presentViewController(loginVC, animated: true, completion: nil) })
                            }
                            alertController.addAction(cancelAction)
                            dispatch_async(dispatch_get_main_queue(), {
                                self.presentViewController(alertController, animated: true, completion: nil)
                            })
                        }else {
                            let alertController = UIAlertController(title: "Failed",
                                                                    message: "Device failed to register. Please try again.", preferredStyle: .Alert)
                            let cancelAction = UIAlertAction(title: "Ok", style: .Cancel) { (action) in
                                let sidepanelvc = self.presentingViewController as! MySidePanelViewController
                                let navvc = sidepanelvc.centerPanel as! UINavigationController
                                let reportVc = navvc.topViewController as! ReportViewController
                                reportVc.shouldMap = false
                                self.navigationController?.pushViewController(reportVc, animated: true)
                            }
                            alertController.addAction(cancelAction)
                            dispatch_async(dispatch_get_main_queue(), {
                                self.presentViewController(alertController, animated: true, completion: nil)
                            })
                        }
                    }
                }
            }
            /*
             let sidepanelvc = self.presentingViewController as! MySidePanelViewController
             let navvc = sidepanelvc.centerPanel as! UINavigationController
             let reportVc = navvc.topViewController as! ReportViewController
             reportVc.shouldMap = false
             self.dismissViewControllerAnimated(true, completion: nil)
             */
            
        }
        
    }

    
    @IBAction func forgotPasswordClicked(_ sender: AnyObject) {
        
        let rvc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
        self.show(rvc, sender: self);
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch:UITouch = (event?.allTouches?.first)!
        if (unameTF.isFirstResponder && touch.view != unameTF && touch.view != passwordTF) {
            unameTF.resignFirstResponder()
        } else if (passwordTF.isFirstResponder && touch.view != unameTF && touch.view != passwordTF) {
            passwordTF.resignFirstResponder()
        }
        super.touchesBegan(touches, with: event)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if (unameTF.text != "" && passwordTF.text != "") {
            signInClicked(loginButton)
            textField.resignFirstResponder();
        } else if (unameTF.text != "" && passwordTF.text == "") {
            passwordTF.becomeFirstResponder()
        } else if (unameTF.text == "" && passwordTF.text != "") {
            unameTF.becomeFirstResponder()
        }
        return true;
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == unameTF || textField == passwordTF {
            DispatchQueue.main.async(execute: {
                self.animateViewMoving(true, moveValue: 100)
            })
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == unameTF || textField == passwordTF {
             DispatchQueue.main.async(execute: {
                self.animateViewMoving(false, moveValue: 100)
            })
        }
    }
    func animateViewMoving (_ up:Bool, moveValue :CGFloat){
        DispatchQueue.main.async(execute: {
            let movementDuration:TimeInterval = 0.3
            let movement:CGFloat = ( up ? -moveValue : moveValue)
            UIView.beginAnimations( "animateView", context: nil)
            UIView.setAnimationBeginsFromCurrentState(true)
            UIView.setAnimationDuration(movementDuration )
            self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
            UIView.commitAnimations()
        })
    }
}

